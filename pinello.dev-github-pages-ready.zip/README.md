# pinello.dev

Página de vendas para criação de websites profissionais, landing pages, lojas virtuais e sistemas sob medida.

## Rodar localmente

Pré-requisito: Node.js 22+.

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy no GitHub Pages

Este projeto já inclui o workflow `.github/workflows/deploy-pages.yml`.

Depois de subir o repositório no GitHub:

1. Abra **Settings → Pages**.
2. Em **Build and deployment**, selecione **GitHub Actions**.
3. Faça push na branch `main`.
4. Aguarde o workflow **Deploy to GitHub Pages** finalizar.

A URL padrão será algo como:

```text
https://pinellon.github.io/NOME-DO-REPOSITORIO/
```

## Observação sobre Gemini/API key

O site é estático. Não coloque `GEMINI_API_KEY` diretamente no GitHub Pages, porque qualquer chave embutida no frontend pode ficar exposta no JavaScript público.

No deploy atual, o consultor com IA pode ficar offline sem afetar a página principal. Para ativar IA com segurança, use um backend/proxy, como Vercel Functions, Cloudflare Workers ou um servidor próprio.
