/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


export interface WebsiteService {
  id: string;
  name: string;
  category: string;
  badge: string;
  image: string;
  description: string;
  features: string[];
  deliveryTime: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}

export enum Section {
  HERO = 'hero',
  SERVICES = 'services',
  EXPERIENCE = 'experience',
  PRICING = 'pricing',
}

