/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { 
  Layout, 
  Laptop, 
  ShoppingBag, 
  Code, 
  Smartphone, 
  TrendingUp, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  PhoneCall, 
  MessageSquare, 
  ArrowRight, 
  Menu, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Zap, 
  Sparkles, 
  Send,
  Eye,
  Settings,
  Flame,
  MousePointerClick
} from 'lucide-react';
import FluidBackground from './components/FluidBackground';
import GradientText from './components/GlitchText';
import CustomCursor from './components/CustomCursor';
import ServiceCard from './components/ServiceCard';
import { WebsiteService } from './types';

// Website Service Custom Solutions Data
const SERVICES: WebsiteService[] = [
  {
    id: '1',
    name: 'Landing Pages',
    category: 'Alta Conversão',
    badge: 'Mais Vendido ⚡',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1000&auto=format&fit=crop',
    description: 'Páginas únicas cirurgicamente desenhadas para converter cliques em leads e vendas de alto valor. Ideais para campanhas de tráfego pago no Meta Ads e Google Ads.',
    features: [
      'Copywriting persuasivo (foco em vendas)',
      'Design ultra-responsivo e mobile-first',
      'Carregamento otimizado abaixo de 1 segundo',
      'Integração direta de WhatsApp e formulários',
      'Pixel do Meta e Google Tags configurados de fábrica'
    ],
    deliveryTime: '5 a 7 dias úteis'
  },
  {
    id: '2',
    name: 'Sites Institucionais',
    category: 'Presença Digital',
    badge: 'Autoridade & Credibilidade',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop',
    description: 'Plataformas completas de páginas corporativas que fortalecem a imagem da sua marca no mercado digital. Excelente para posicionar serviços e história de forma sofisticada.',
    features: [
      'Até 5 páginas personalizadas exclusivas',
      'Otimização avançada de SEO para ranquear no Google',
      'Seção rica para portfólio de serviços ou cases',
      'Integração para Blog corporativo opcional',
      'Painel autogerenciável para atualizar seus conteúdos'
    ],
    deliveryTime: '10 a 15 dias úteis'
  },
  {
    id: '3',
    name: 'Lojas Virtuais',
    category: 'E-commerce',
    badge: 'Máxima Performance',
    image: 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?q=80&w=1000&auto=format&fit=crop',
    description: 'Plataforma de e-commerce sem taxas sobre suas vendas. Layout intuitivo pensado para otimizar a experiência de compra em todos os dispositivos.',
    features: [
      'Gestão ilimitada de produtos e categorias',
      'Checkout rápido e seguro de página única (One-Page)',
      'Integração com Mercado Pago, Stripe, Pix e boleto',
      'Cálculo de frete em tempo real (Correios/Melhor Envio)',
      'Painel de acompanhamento de vendas e controle de estoque'
    ],
    deliveryTime: '15 a 25 dias úteis'
  },
  {
    id: '4',
    name: 'Sistemas Web',
    category: 'Soluções Customizadas',
    badge: 'SaaS & Plataformas',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=1000&auto=format&fit=crop',
    description: 'Plataformas web customizadas de alta complexidade para automatizar os fluxos operacionais da sua empresa ou tirar seu projeto de startup do papel.',
    features: [
      'Banco de dados altamente seguro e escalável',
      'Fluxo de autenticação completo de usuários',
      'Painéis de controle administrativos (Dashboards)',
      'Integrações com APIs externas e sistemas legados',
      'Arquitetura em nuvem monitorada de alta velocidade'
    ],
    deliveryTime: 'Sob briefing detalhado'
  },
  {
    id: '5',
    name: 'Agendamentos Inteligentes',
    category: 'Automatização',
    badge: 'Eficiência Pura',
    image: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?q=80&w=1000&auto=format&fit=crop',
    description: 'Sistemas de reserva automatizada em tempo real. Ideal para clínicas médicas, escritórios jurídicos, consultórios e prestadores de serviços recorrentes.',
    features: [
      'Calendário inteligente integrado ao Google Calendar',
      'Confirmação e notificações automáticas via WhatsApp',
      'Painéis independentes para agendamentos de colaboradores',
      'Opção de pré-pagamento online do agendamento',
      'Histórico e gerenciamento de sessões dos clientes'
    ],
    deliveryTime: '7 a 12 dias úteis'
  },
  {
    id: '6',
    name: 'Portfólios Criativos',
    category: 'Vitrines Exclusivas',
    badge: 'Impacto Estético',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=1000&auto=format&fit=crop',
    description: 'Vitrines dinâmicas com transições cinematográficas de alta performance para fotógrafos, designers, artistas e marcas que exigem excelência visual.',
    features: [
      'Animações premium sob medida em Framer Motion',
      'Galeria de mídias otimizada para carregar sem gargalos',
      'Totalmente personalizado com a sua marca criativa',
      'Forte apelo de posicionamento de mercado premium',
      'Formas de contato direto e rápido integradas'
    ],
    deliveryTime: '7 a 10 dias úteis'
  }
];

const WHATSAPP_NUMBER = '5511943022963';

const CODE_EXAMPLES = {
  landing: `// ⚡ landing-page-conversao.tsx
import React from 'react';
import { WhatsAppBtn } from '@/components';

export default function HighConvertingLP() {
  return (
    <main className="bg-black text-cyan-400">
      <Hero 
        title="Dobre suas vendas com velocidade" 
        pageSpeedScore={100} 
      />
      
      {/* Botão estratégico integrado com Meta Pixel */}
      <WhatsAppBtn 
        number="5511943022963"
        message="Quero solicitar meu site"
        onConversion={() => trackPixel('Lead_WhatsApp')}
      />
    </main>
  );
}`,
  seo: `// 🔍 seo-otimizacao-google.ts
export const metadata = {
  title: 'Pinello Dev - Desenvolvimento de Sites',
  description: 'Landing Pages sob medida para faturar alto.',
  robots: {
    index: true,
    follow: true,
    nocache: false,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
    },
  },
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    url: 'https://pinello.dev',
  }
};`,
  performance: `// 🚀 fast-loading-styles.css
/* Código puro e otimizado sem frameworks pesados */
.hero-wrapper {
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: 1.5rem;
  content-visibility: auto; /* Carrega apenas o que está na tela */
  contain-intrinsic-size: 0 500px;
}

@media (max-width: 768px) {
  .hero-wrapper {
    grid-template-columns: 1fr;
    padding: 1rem;
  }
}`
};

const App: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<WebsiteService | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'landing' | 'seo' | 'performance'>('landing');

  // Touch particle effect for mobile
  const [touchParticles, setTouchParticles] = useState<{ id: number; x: number; y: number }[]>([]);

  // Budget Calculator State
  const [calcPlan, setCalcPlan] = useState<'lp' | 'inst' | 'ecommerce'>('lp');
  const [calcAddons, setCalcAddons] = useState<{ [key: string]: boolean }>({
    copy: false,
    blog: false,
    whatsapp: true,
    maintenance: false,
  });

  // Briefing Form State
  const [briefing, setBriefing] = useState({
    nome: '',
    empresa: '',
    email: '',
    whatsapp: '',
    mensagem: ''
  });

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedService) return;
      if (e.key === 'ArrowLeft') navigateService('prev');
      if (e.key === 'ArrowRight') navigateService('next');
      if (e.key === 'Escape') setSelectedService(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedService]);

  // Touch / click ripple dynamic effect for mobile
  const handlePageTouch = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    let clientX = 0;
    let clientY = 0;
    if ('touches' in e) {
      if (e.touches.length === 0) return;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const newParticle = {
      id: Date.now() + Math.random(),
      x: clientX,
      y: clientY
    };
    setTouchParticles(prev => [...prev.slice(-10), newParticle]);
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const navigateService = (direction: 'next' | 'prev') => {
    if (!selectedService) return;
    const currentIndex = SERVICES.findIndex(s => s.id === selectedService.id);
    let nextIndex;
    if (direction === 'next') {
      nextIndex = (currentIndex + 1) % SERVICES.length;
    } else {
      nextIndex = (currentIndex - 1 + SERVICES.length) % SERVICES.length;
    }
    setSelectedService(SERVICES[nextIndex]);
  };

  // Pricing values
  const basePrices = {
    lp: 490,
    inst: 990,
    ecommerce: 1890,
  };

  const addonPrices = {
    copy: 100,
    blog: 150,
    whatsapp: 50,
    maintenance: 100,
  };

  const getPlanLabel = () => {
    if (calcPlan === 'lp') return 'Landing Page Pro';
    if (calcPlan === 'inst') return 'Site Institucional';
    return 'E-commerce Custom';
  };

  const calculateTotal = () => {
    let total = basePrices[calcPlan];
    if (calcAddons.copy) total += addonPrices.copy;
    if (calcAddons.blog) total += addonPrices.blog;
    if (calcAddons.whatsapp) total += addonPrices.whatsapp;
    if (calcAddons.maintenance) total += addonPrices.maintenance;
    return total;
  };

  const toggleAddon = (key: string) => {
    setCalcAddons(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Build the WhatsApp direct link and send briefing
  const triggerWhatsAppBudget = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const planLabel = getPlanLabel();
    const totalEst = calculateTotal().toLocaleString('pt-BR');
    
    // Gather selected addons
    const selectedAddonsText: string[] = [];
    if (calcAddons.copy) selectedAddonsText.push(`Copywriting Profissional (R$ ${addonPrices.copy})`);
    if (calcAddons.blog) selectedAddonsText.push(`Módulo de Blog Integrado (R$ ${addonPrices.blog})`);
    if (calcAddons.whatsapp) selectedAddonsText.push(`Integração de WhatsApp (R$ ${addonPrices.whatsapp})`);
    if (calcAddons.maintenance) selectedAddonsText.push(`Suporte & Manutenção Mensal (R$ ${addonPrices.maintenance})`);
    
    const addonsString = selectedAddonsText.length > 0 
      ? selectedAddonsText.map(a => `• ${a}`).join('%0A') 
      : 'Nenhum adicional selecionado';

    // Format the text message elegantly for WhatsApp API
    const textMessage = `Olá, pinello.dev! 👋%0A` +
      `Gostaria de fazer o orçamento do meu novo site.%0A%0A` +
      `💻 *SIMULAÇÃO DO PROJETO*%0A` +
      `• *Plano Escolhido:* ${planLabel} (R$ ${basePrices[calcPlan].toLocaleString('pt-BR')})%0A` +
      `• *Adicionais:*%0A${addonsString}%0A` +
      `💰 *Investimento Estimado:* R$ ${totalEst}%0A%0A` +
      `👤 *MEUS DADOS*%0A` +
      `• *Nome:* ${briefing.nome || 'Não informado'}%0A` +
      `• *Empresa:* ${briefing.empresa || 'Não informada'}%0A` +
      `• *E-mail:* ${briefing.email || 'Não informado'}%0A` +
      `• *WhatsApp:* ${briefing.whatsapp || 'Não informado'}%0A%0A` +
      `🎯 *MINHA IDEIA / BRIEFING*%0A` +
      `"${briefing.mensagem || 'Gostaria de agendar uma reunião para detalhar o projeto!'}"`;

    const whatsappUrl = `https://api.whatsapp.com/send?phone=${WHATSAPP_NUMBER}&text=${textMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div 
      onPointerDown={handlePageTouch}
      className="relative min-h-screen text-white bg-[#030305] selection:bg-[#4fb7b3] selection:text-black cursor-auto md:cursor-none overflow-x-hidden"
    >
      <CustomCursor />
      <FluidBackground />

      {/* Floating Touch / Tap Ripple Particles (Mobile Effect) */}
      <AnimatePresence>
        {touchParticles.map((p) => (
          <motion.div
            key={p.id}
            initial={{ scale: 0.1, opacity: 1 }}
            animate={{ scale: 3.5, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="fixed pointer-events-none z-[9999] w-6 h-6 rounded-full border border-[#a8fbd3] bg-[#4fb7b3]/10 -ml-3 -mt-3"
            style={{ left: p.x, top: p.y }}
          />
        ))}
      </AnimatePresence>

      {/* Floating Direct WhatsApp Icon with Notification Badge */}
      <motion.div 
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 2, type: 'spring' }}
        className="fixed bottom-6 left-6 z-50 hidden sm:flex items-center gap-3 group"
      >
        <a 
          href={`https://api.whatsapp.com/send?phone=${WHATSAPP_NUMBER}&text=Olá,%20pinello.dev!%20Gostaria%20de%20conversar%20sobre%20um%20novo%20site.`}
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-[0_0_20px_rgba(37,211,102,0.5)] border border-white/20 transition-transform duration-300 hover:scale-110 relative"
          data-hover="true"
        >
          <PhoneCall className="w-6 h-6 fill-current animate-pulse" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-[9px] font-bold text-white animate-bounce">
            1
          </span>
        </a>
        <div className="bg-black/85 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-white/10 text-xs font-mono font-medium tracking-wide scale-0 group-hover:scale-100 origin-left transition-all duration-200">
          Orçamento no Zap
        </div>
      </motion.div>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-6 md:px-8 py-6 mix-blend-difference">
        <div className="font-heading text-xl md:text-2xl font-bold tracking-tighter text-white cursor-default z-50">PINELLO.DEV</div>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex gap-10 text-sm font-bold tracking-widest uppercase">
          {['Soluções', 'Diferenciais', 'Planos', 'Orçamento'].map((item) => {
            const sectionMap: { [key: string]: string } = {
              'Soluções': 'solucoes',
              'Diferenciais': 'diferenciais',
              'Planos': 'planos',
              'Orçamento': 'orcamento'
            };
            return (
              <button 
                key={item} 
                onClick={() => scrollToSection(sectionMap[item])}
                className="hover:text-[#a8fbd3] transition-colors text-white cursor-pointer bg-transparent border-none"
                data-hover="true"
              >
                {item}
              </button>
            );
          })}
        </div>
        <button 
          onClick={() => scrollToSection('orcamento')}
          className="hidden md:inline-block border border-white px-8 py-3 text-xs font-bold tracking-widest uppercase hover:bg-[#a8fbd3] hover:text-black hover:border-[#a8fbd3] transition-all duration-300 text-white cursor-pointer bg-transparent"
          data-hover="true"
        >
          Pedir Orçamento no Zap
        </button>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden text-white z-50 relative w-10 h-10 flex items-center justify-center"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
           {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-30 bg-[#06070a]/98 backdrop-blur-xl flex flex-col items-center justify-center gap-8 md:hidden"
          >
            {[
              { label: 'Soluções', id: 'solucoes' },
              { label: 'Diferenciais', id: 'diferenciais' },
              { label: 'Planos', id: 'planos' },
              { label: 'Orçamento', id: 'orcamento' }
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => scrollToSection(item.id)}
                className="text-3xl font-heading font-bold text-white hover:text-[#a8fbd3] transition-colors uppercase bg-transparent border-none"
              >
                {item.label}
              </button>
            ))}
            <a 
              href={`https://api.whatsapp.com/send?phone=${WHATSAPP_NUMBER}&text=Olá!%20Estou%20no%20site%20da%20pinello.dev%20e%20gostaria%20de%20solicitar%20um%20orçamento.`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 border border-[#25D366] bg-[#25D366]/10 px-10 py-4 text-sm font-bold tracking-widest uppercase text-[#25D366] text-center"
            >
              Chamar no WhatsApp ⚡
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* HERO SECTION */}
      <header className="relative h-[100svh] min-h-[650px] flex flex-col items-center justify-center overflow-hidden px-4">
        <motion.div 
          style={{ y, opacity }}
          className="z-10 text-center flex flex-col items-center w-full max-w-6xl pb-24 md:pb-20"
        >
          {/* Mobile Tap Interactive Hint */}
          <div className="md:hidden flex items-center gap-2 text-[10px] font-mono text-white/40 uppercase mb-4 animate-pulse">
            <MousePointerClick className="w-3.5 h-3.5 text-[#4fb7b3]" />
            Toque na tela para efeito interativo
          </div>

          {/* Agency Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="flex items-center gap-3 md:gap-4 text-xs md:text-sm font-mono text-[#a8fbd3] tracking-[0.2em] md:tracking-[0.3em] uppercase mb-6 bg-black/40 px-6 py-2.5 rounded-full border border-white/5 backdrop-blur-sm"
          >
            <span>Websites de Alta Performance</span>
            <span className="w-2 h-2 bg-[#4fb7b3] rounded-full animate-ping"/>
            <span>Design Ultra Dark Premium</span>
          </motion.div>

          {/* Main Title */}
          <div className="relative w-full flex flex-col justify-center items-center">
            <span className="text-[12vw] md:text-[8vw] leading-[0.9] font-black tracking-tighter text-center text-white/95 block">
              SITES QUE
            </span>
            <GradientText 
              text="VENDEM." 
              as="h1" 
              className="text-[14vw] md:text-[10vw] leading-[0.9] font-black tracking-tighter text-center" 
            />
            {/* Ambient Orb */}
            <motion.div 
               className="absolute -z-20 w-[60vw] h-[60vw] bg-[#4fb7b3]/5 blur-[90px] rounded-full pointer-events-none will-change-transform"
               animate={{ scale: [0.95, 1.05, 0.95], opacity: [0.2, 0.4, 0.2] }}
               transition={{ duration: 8, repeat: Infinity }}
               style={{ transform: 'translateZ(0)' }}
            />
          </div>
          
          <motion.div
             initial={{ scaleX: 0 }}
             animate={{ scaleX: 1 }}
             transition={{ duration: 1.5, delay: 0.5, ease: "circOut" }}
             className="w-full max-w-lg h-px bg-gradient-to-r from-transparent via-white/20 to-transparent mt-6 md:mt-10 mb-8 md:mb-10"
          />

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 1 }}
            className="text-base md:text-2xl font-light max-w-2xl mx-auto text-gray-300 leading-relaxed px-4"
          >
            Landing Pages exclusivas, e-commerces rápidos e plataformas sob medida programados em código puro para faturar alto e fechar clientes diretamente no seu WhatsApp.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 1 }}
            className="flex flex-col sm:flex-row gap-4 mt-8 md:mt-12 z-20"
          >
            <button
              onClick={() => scrollToSection('solucoes')}
              className="px-8 py-4 text-xs font-bold tracking-widest uppercase bg-white text-black hover:bg-transparent hover:text-white border border-white transition-all duration-300 rounded-none cursor-pointer"
              data-hover="true"
            >
              Ver Soluções
            </button>
            <button
              onClick={() => scrollToSection('orcamento')}
              className="px-8 py-4 text-xs font-bold tracking-widest uppercase bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/40 hover:bg-[#25D366] hover:text-white transition-all duration-300 rounded-none cursor-pointer flex items-center justify-center gap-2"
              data-hover="true"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              Chamar no WhatsApp
            </button>
          </motion.div>
        </motion.div>

        {/* MARQUEE */}
        <div className="absolute bottom-6 md:bottom-12 left-0 w-full py-4 bg-white text-black z-20 overflow-hidden border-y-4 border-black shadow-[0_0_30px_rgba(79,183,179,0.2)]">
          <motion.div 
            className="flex w-fit will-change-transform"
            animate={{ x: "-50%" }}
            transition={{ duration: 32, repeat: Infinity, ease: "linear" }}
          >
            {[0, 1].map((key) => (
              <div key={key} className="flex whitespace-nowrap shrink-0">
                {[...Array(3)].map((_, i) => (
                  <span key={i} className="text-xl md:text-3xl font-heading font-black px-8 flex items-center gap-4">
                    SITES EM CÓDIGO PURO <span className="text-cyan-600">●</span> 
                    ORÇAMENTO DIRETO VIA WHATSAPP <span className="text-cyan-600">●</span> 
                    SEM TEMPLATES PRONTOS DO WORDPRESS <span className="text-cyan-600">●</span> 
                    PAGESPEED METRICS 100% <span className="text-cyan-600">●</span>
                  </span>
                ))}
              </div>
            ))}
          </motion.div>
        </div>
      </header>

      {/* PORTFOLIO / SOLUTIONS SECTION */}
      <section id="solucoes" className="relative z-10 py-24 md:py-36">
        <div className="max-w-[1600px] mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 px-4">
             <div>
               <span className="text-xs font-mono font-bold tracking-widest text-[#4fb7b3] uppercase block mb-3">O que desenvolvemos</span>
               <h2 className="text-4xl md:text-7xl font-heading font-bold uppercase leading-[0.9] drop-shadow-lg break-words">
                Nossos <br/> 
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#a8fbd3] to-[#4fb7b3]">Modelos</span>
              </h2>
             </div>
             <p className="text-gray-300 max-w-md text-sm md:text-base font-light mt-6 md:mt-0 leading-relaxed">
               Cada página é programada sob medida. Do portfólio visual de impacto ao e-commerce automatizado de alta performance estruturado para fechar vendas no WhatsApp.
             </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 border-t border-l border-white/10 bg-black/40 backdrop-blur-sm">
            {SERVICES.map((service) => (
              <ServiceCard key={service.id} service={service} onClick={() => setSelectedService(service)} />
            ))}
          </div>
        </div>
      </section>

      {/* VALUE PROPOSITION / DIFFERENTIALS SECTION */}
      <section id="diferenciais" className="relative z-10 py-24 md:py-36 bg-black/30 backdrop-blur-sm border-t border-white/10 overflow-hidden">
        <div className="absolute top-1/2 right-[-20%] w-[50vw] h-[50vw] bg-[#4fb7b3]/5 rounded-full blur-[80px] pointer-events-none will-change-transform" style={{ transform: 'translateZ(0)' }} />

        <div className="max-w-7xl mx-auto px-4 md:px-6 relative text-center">
          <span className="text-xs font-mono font-bold tracking-widest text-[#4fb7b3] uppercase block mb-3">Vantagem Exclusiva</span>
          <h2 className="text-4xl md:text-6xl font-heading font-bold mb-8 leading-tight">
            A Revolução do <br /> <GradientText text="DARK COGNITIVE" className="text-4.5xl md:text-6xl" />
          </h2>
          <p className="text-base md:text-lg text-gray-300 mb-16 font-light leading-relaxed max-w-3xl mx-auto">
            Nosso ecossistema de design escuro ultra-moderno não é apenas esteticamente impecável. Ele consome até 40% menos bateria nos celulares dos seus leads, reduz o cansaço visual e aumenta o tempo de retenção na página.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            {[
              { icon: Zap, title: 'Conversão no WhatsApp', desc: 'Sistemas inteligentes integrados com botões estratégicos que guiam o lead até o seu contato direto no WhatsApp.' },
              { icon: TrendingUp, title: 'Carregamento Instantâneo', desc: 'Páginas sem scripts desnecessários. Seu lead clica no anúncio e a página abre instantaneamente.' },
              { icon: ShieldCheck, title: 'Hospedagem Blindada', desc: 'Proteção DNS contra quedas e tráfego malicioso. Estabilidade e velocidade absoluta 24 horas por dia.' },
            ].map((feature, i) => (
              <div key={i} className="flex flex-col items-start gap-5 p-6 rounded-2xl bg-white/[0.02] border border-white/5 backdrop-blur-md hover:border-white/10 transition-all duration-300">
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md">
                  <feature.icon className="w-5 h-5 text-[#4fb7b3]" />
                </div>
                <div>
                  <h4 className="text-lg font-bold mb-2 font-heading text-white">{feature.title}</h4>
                  <p className="text-sm text-gray-400 font-light leading-relaxed">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SEÇÃO CÓDIGO PURO / ENGENHARIA */}
      <section className="relative z-10 py-24 md:py-36 border-t border-white/10 bg-black/40 overflow-hidden">
        <div className="absolute top-1/3 left-[-10%] w-[40vw] h-[40vw] bg-[#637ab9]/5 rounded-full blur-[90px] pointer-events-none will-change-transform" style={{ transform: 'translateZ(0)' }} />
        <div className="absolute bottom-1/3 right-[-10%] w-[40vw] h-[40vw] bg-[#4fb7b3]/5 rounded-full blur-[90px] pointer-events-none will-change-transform" style={{ transform: 'translateZ(0)' }} />

        <div className="max-w-7xl mx-auto px-4 md:px-6 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Texto explicativo lateral */}
            <div className="lg:col-span-5">
              <span className="text-xs font-mono font-bold tracking-widest text-[#4fb7b3] uppercase block mb-3">Artesanal & Programado</span>
              <h2 className="text-4xl md:text-6xl font-heading font-bold mb-6 leading-tight uppercase text-white">
                Código Puro <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#a8fbd3] to-[#4fb7b3]">Sem Amarras</span>
              </h2>
              <p className="text-base text-gray-300 mb-8 font-light leading-relaxed">
                Esqueça builders lentos como WordPress ou Elementor. Nós programamos cada linha do seu site à mão usando tecnologias de ponta como <strong>React, Vite, TypeScript e Tailwind CSS</strong>. O resultado é velocidade extrema, segurança intransponível e ranqueamento superior no Google.
              </p>

              <div className="space-y-4">
                {[
                  { title: 'Zero Bloatware', desc: 'Sem plugins desnecessários deixando seu site lento ou vulnerável a invasões.' },
                  { title: 'PageSpeed Score 100%', desc: 'Código limpo com carregamento rápido que agrada o Google e retém os leads.' },
                  { title: 'Responsividade Cirúrgica', desc: 'Layouts perfeitamente adaptados em qualquer tela ou dispositivo móvel.' }
                ].map((item, i) => (
                  <div key={i} className="flex gap-4 items-start">
                    <span className="text-xs font-mono font-bold text-[#a8fbd3] mt-1">{'0' + (i + 1) + '.'}</span>
                    <div>
                      <h4 className="text-base font-bold text-white font-heading">{item.title}</h4>
                      <p className="text-sm text-gray-400 font-light mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Terminal / IDE interativo */}
            <div className="lg:col-span-7 bg-[#0c0d12]/90 rounded-2xl border border-white/10 overflow-hidden shadow-[0_0_50px_rgba(79,183,179,0.05)]">
              {/* Top bar do Terminal */}
              <div className="flex items-center justify-between px-6 py-4 bg-[#06070a] border-b border-white/5">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/85" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/85" />
                  <div className="w-3 h-3 rounded-full bg-green-500/85" />
                  <span className="text-xs font-mono text-gray-500 ml-4">pinello.dev — workspace</span>
                </div>
                <div className="flex items-center gap-1 bg-white/5 px-2.5 py-1 rounded text-[10px] font-mono text-cyan-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse mr-1" />
                  typescript
                </div>
              </div>

              {/* Seletor de Arquivos / Abas */}
              <div className="flex border-b border-white/5 bg-[#08090d] overflow-x-auto scrollbar-none">
                {[
                  { id: 'landing', label: 'conversao.tsx' },
                  { id: 'seo', label: 'google-seo.ts' },
                  { id: 'performance', label: 'styles.css' }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveCodeTab(tab.id as 'landing' | 'seo' | 'performance')}
                    className={`px-5 py-3 text-xs font-mono border-r border-white/5 transition-all duration-200 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                      activeCodeTab === tab.id 
                        ? 'bg-[#0c0d12] text-[#a8fbd3] border-b-2 border-b-[#4fb7b3]' 
                        : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.01]'
                    }`}
                  >
                    <Code className="w-3.5 h-3.5" />
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Área do Código com numeração de linhas */}
              <div className="p-6 overflow-x-auto font-mono text-xs text-gray-300 leading-relaxed bg-[#0c0d12]/95 min-h-[300px]">
                <div className="flex gap-4">
                  {/* Números das linhas */}
                  <div className="text-right text-gray-600 select-none pr-3 border-r border-white/5">
                    {CODE_EXAMPLES[activeCodeTab].split('\n').map((_, index) => (
                      <div key={index} className="h-5">{index + 1}</div>
                    ))}
                  </div>
                  {/* Conteúdo do Código com estilização rica de tokens */}
                  <pre className="flex-1 whitespace-pre select-all text-left">
                    {CODE_EXAMPLES[activeCodeTab].split('\n').map((line, idx) => {
                      const highlightLine = (lineStr: string) => {
                        return lineStr
                          .replace(/(const|let|var|function|export|import|from|default|return|interface|export|default)/g, '<span class="text-[#637ab9] font-bold">$1</span>')
                          .replace(/(true|false)/g, '<span class="text-orange-400 font-bold">$1</span>')
                          .replace(/("[^"\\]*")|('[^'\\]*')/g, '<span class="text-[#a8fbd3] font-light">$1</span>')
                          .replace(/(\/\/.*)/g, '<span class="text-gray-500 italic">$1</span>')
                          .replace(/(&lt;[a-zA-Z0-9_]+\s|&lt;\/[a-zA-Z0-9_]+&gt;|&lt;[a-zA-Z0-9_]+&gt;|&lt;[a-zA-Z0-9_]+\/&gt;)/g, '<span class="text-[#4fb7b3] font-medium">$1</span>');
                      };

                      const escapedLine = line
                        .replace(/&/g, '&amp;')
                        .replace(/</g, '&lt;')
                        .replace(/>/g, '&gt;');

                      return (
                        <div 
                          key={idx} 
                          className="h-5 hover:bg-white/[0.02] px-1 rounded transition-colors"
                          dangerouslySetInnerHTML={{ __html: highlightLine(escapedLine) }}
                        />
                      );
                    })}
                  </pre>
                </div>
              </div>

              {/* Linha de status inferior */}
              <div className="px-6 py-2.5 bg-[#06070a] border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-gray-500">
                <div className="flex items-center gap-4">
                  <span>UTF-8</span>
                  <span>TypeScript React</span>
                </div>
                <span>Linhas: {CODE_EXAMPLES[activeCodeTab].split('\n').length}</span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* PLANOS & PREÇOS SECTION */}
      <section id="planos" className="relative z-10 py-24 md:py-36 px-4 md:px-6 bg-[#06070c]/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
             <span className="text-xs font-mono font-bold tracking-widest text-[#4fb7b3] uppercase block mb-3">Modelos de Negócios</span>
             <h2 className="text-5xl md:text-8xl font-heading font-bold opacity-[0.03] text-white leading-none">
               INVESTIMENTO
             </h2>
             <p className="text-[#a8fbd3] font-mono uppercase tracking-widest -mt-4 md:-mt-6 relative z-10 text-sm md:text-lg">
               Selecione um Plano e Feche no WhatsApp
             </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { 
                id: 'lp',
                name: 'Landing Page Pro', 
                price: 'R$ 490', 
                sub: 'Chame direto no Zap para fechar', 
                color: 'white', 
                accent: 'bg-white/[0.02]',
                desc: 'Focada em conversão ultra-rápida. Estruturada cirurgicamente para Meta Ads.',
                features: ['Design Escuro Exclusivo', 'Integração direta com o WhatsApp', 'Tags de Rastreamento (Pixel/Analytics)', 'Prazo de entrega: 5-7 dias', 'Primeiro mês de manutenção grátis']
              },
              { 
                id: 'inst',
                name: 'Site Institucional', 
                price: 'R$ 990', 
                sub: 'O melhor custo-benefício', 
                color: 'teal', 
                accent: 'bg-[#4fb7b3]/5 border-[#4fb7b3]/30',
                desc: 'Aumente a autoridade da sua marca. Ideal para ranquear organicamente no Google.',
                features: ['Até 5 páginas personalizadas', 'Módulo de Blog ou Galeria de Cases', 'Otimização avançada de SEO', 'Prazo de entrega: 10-15 dias', 'Código limpo de alta performance']
              },
              { 
                id: 'ecommerce',
                name: 'E-commerce Custom', 
                price: 'R$ 1.890', 
                sub: 'Checkout integrado inteligente', 
                color: 'periwinkle', 
                accent: 'bg-[#637ab9]/5 border-[#637ab9]/30',
                desc: 'Sua loja virtual completa em código puro. Cadastro ilimitado de produtos e carrinho.',
                features: ['Área administrativa intuitiva', 'Integração de pagamento direto', 'Cálculo de frete em tempo real', 'Foco em conversão mobile-first', 'Suporte pós-lançamento incluso']
              },
            ].map((ticket, i) => {
              return (
                <motion.div
                  key={i}
                  whileHover={{ y: -10 }}
                  className={`relative p-8 md:p-10 border border-white/10 backdrop-blur-md flex flex-col min-h-[500px] md:min-h-[580px] transition-all duration-300 ${ticket.accent} will-change-transform`}
                  data-hover="true"
                >
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                  
                  <div className="flex-1">
                    <h3 className="text-xl md:text-2xl font-heading font-bold mb-2 text-white">{ticket.name}</h3>
                    <p className="text-xs text-gray-400 font-light mb-6 leading-relaxed">{ticket.desc}</p>
                    <div className={`text-4xl md:text-5xl font-bold tracking-tighter ${ticket.color === 'white' ? 'text-white' : ticket.color === 'teal' ? 'text-[#4fb7b3]' : 'text-[#a8fbd3]'}`}>
                      {ticket.price}
                    </div>
                    <p className="text-xs font-mono text-[#a8fbd3] mb-8 mt-1">{ticket.sub}</p>
                    
                    <ul className="space-y-4 text-sm text-gray-200">
                      {ticket.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-3">
                          <CheckCircle2 className="w-4 h-4 text-[#4fb7b3] shrink-0" /> 
                          <span className="font-light">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <button 
                    onClick={() => {
                      setCalcPlan(ticket.id as 'lp' | 'inst' | 'ecommerce');
                      scrollToSection('orcamento');
                    }}
                    className="w-full py-4 text-xs font-bold uppercase tracking-[0.2em] border border-white/10 hover:border-[#a8fbd3] hover:text-[#a8fbd3] transition-all duration-300 mt-8 group overflow-hidden relative cursor-pointer text-white bg-transparent"
                  >
                    Selecionar Plano
                  </button>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* DETAILED INTERACTIVE BUDGET CALCULATOR & BRIEFING FORM WITH LIVE MOBILE PREVIEW */}
      <section id="orcamento" className="relative z-10 py-24 md:py-36 px-4 md:px-6 bg-[#090a10]/90 border-t border-white/10 backdrop-blur-md">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-mono font-bold tracking-widest text-[#4fb7b3] uppercase block mb-3">Orçamento Inteligente</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold uppercase">Simule & Chame no <span className="text-[#25D366]">Zap</span></h2>
            <p className="text-gray-300 font-light mt-4">Personalize as configurações do seu projeto na simulação interativa abaixo. Os dados são estruturados automaticamente e enviados para nosso WhatsApp de atendimento.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            
            {/* Dynamic Interactive Smartphone Live Site Builder Preview (Responsive Mobile Effect) */}
            <div className="lg:col-span-4 bg-black/60 p-6 border border-white/10 rounded-3xl backdrop-blur-sm flex flex-col items-center justify-between min-h-[500px] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#4fb7b3]/5 blur-[45px] rounded-full pointer-events-none" />
              
              <div className="w-full text-center border-b border-white/10 pb-4 mb-4">
                <span className="text-[10px] font-mono text-[#a8fbd3] tracking-wider uppercase block">Simulador de Página Mobile</span>
                <p className="text-[9px] text-gray-400 mt-1">Veja seu site se adaptar em tempo real</p>
              </div>

              {/* Smartphone Frame Outer Mock */}
              <div className="w-[230px] h-[400px] border-[6px] border-[#222] bg-[#0c0d13] rounded-[36px] p-3 shadow-2xl relative flex flex-col justify-between overflow-hidden">
                {/* Speaker/Camera Notch */}
                <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-20 flex items-center justify-center gap-1.5">
                  <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full" />
                  <div className="w-8 h-1 bg-neutral-800 rounded-full" />
                </div>

                {/* Smartphone Screen Inner */}
                <div className="flex-1 flex flex-col justify-between bg-[#06070a] rounded-[24px] p-3.5 pt-6 text-left relative overflow-hidden text-white font-sans">
                  
                  {/* Performance Badge Top Right */}
                  <div className="absolute top-2 right-2 flex items-center gap-1 bg-[#4fb7b3]/10 border border-[#4fb7b3]/30 px-1.5 py-0.5 rounded text-[8px] font-mono text-[#a8fbd3]">
                    <Flame className="w-2.5 h-2.5 text-[#a8fbd3]" />
                    <span>Speed: 100</span>
                  </div>

                  {/* Header Screen Mock */}
                  <div className="border-b border-white/5 pb-2">
                    <span className="text-[10px] font-black tracking-tight font-heading text-white block uppercase">
                      {briefing.empresa || 'Sua Empresa'}
                    </span>
                    <span className="text-[6px] text-gray-400 block -mt-0.5 font-mono">Padrão Elite Programado</span>
                  </div>

                  {/* Main Display Area Mock */}
                  <div className="flex-1 flex flex-col justify-center py-4 space-y-2">
                    <div className="h-1.5 w-12 bg-[#4fb7b3]/20 rounded" />
                    <h5 className="text-xs font-heading font-black leading-tight uppercase text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">
                      {calcPlan === 'lp' ? 'O Melhor Produto Aqui' : calcPlan === 'inst' ? 'Nossos Serviços Premium' : 'Vitrine de Ofertas'}
                    </h5>
                    <p className="text-[7px] text-gray-400 font-light line-clamp-3 leading-normal">
                      Instalamos gatilhos de vendas de alto impacto projetados exclusivamente para a sua marca converter visitantes em leads quentes.
                    </p>

                    {/* Blog Module Addon Mock */}
                    {calcAddons.blog && (
                      <motion.div 
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-white/5 p-1 rounded border border-white/5"
                      >
                        <span className="text-[6px] font-bold text-[#a8fbd3] block font-mono">ÚLTIMAS DO BLOG</span>
                        <div className="h-1 w-20 bg-white/20 rounded mt-0.5" />
                      </motion.div>
                    )}

                    {/* Copywriting Snippet Addon Mock */}
                    {calcAddons.copy && (
                      <motion.p 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-[6px] text-[#4fb7b3] italic"
                      >
                        ⚡ "Oferta limitada. Garanta seu atendimento personalizado hoje!"
                      </motion.p>
                    )}
                  </div>

                  {/* Mobile Footer Screen Mock */}
                  <div className="border-t border-white/5 pt-2 flex justify-between items-center">
                    <div className="flex flex-col">
                      <span className="text-[5px] text-gray-500 font-mono">INVESTIMENTO BASE</span>
                      <span className="text-[9px] font-bold text-[#a8fbd3] font-mono">
                        R$ {basePrices[calcPlan].toLocaleString('pt-BR')}
                      </span>
                    </div>

                    {/* Floating Zap Mobile Screen Mock */}
                    {calcAddons.whatsapp && (
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-5 h-5 bg-[#25D366] rounded-full flex items-center justify-center text-white shadow-md cursor-pointer"
                      >
                        <PhoneCall className="w-2.5 h-2.5 fill-current" />
                      </motion.div>
                    )}
                  </div>

                </div>
              </div>

              {/* PageSpeed Performance Metrics Mock */}
              <div className="w-full flex justify-between items-center gap-2 mt-4 px-2">
                <div className="text-center flex-1">
                  <div className="text-xs font-mono font-bold text-[#25D366]">100%</div>
                  <div className="text-[8px] text-gray-400 uppercase tracking-widest font-mono">Acessibilidade</div>
                </div>
                <div className="text-center flex-1">
                  <div className="text-xs font-mono font-bold text-[#25D366]">100%</div>
                  <div className="text-[8px] text-gray-400 uppercase tracking-widest font-mono">Desempenho</div>
                </div>
                <div className="text-center flex-1">
                  <div className="text-xs font-mono font-bold text-[#25D366]">0.2s</div>
                  <div className="text-[8px] text-gray-400 uppercase tracking-widest font-mono">Carregamento</div>
                </div>
              </div>
            </div>

            {/* Calculator Control & Briefing Column */}
            <div className="lg:col-span-8 flex flex-col justify-between bg-black/30 p-8 md:p-10 border border-white/10 rounded-3xl backdrop-blur-sm">
              <form onSubmit={triggerWhatsAppBudget} className="space-y-6">
                
                {/* Step 1: Base Plan Toggles */}
                <div>
                  <span className="text-xs font-mono text-[#a8fbd3] uppercase tracking-wider block mb-3">1. Escolha o Plano Base do Site:</span>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'lp', label: 'Landing Page', price: 'R$ 490' },
                      { id: 'inst', label: 'Institucional', price: 'R$ 990' },
                      { id: 'ecommerce', label: 'E-commerce', price: 'R$ 1.890' }
                    ].map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setCalcPlan(p.id as 'lp' | 'inst' | 'ecommerce')}
                        className={`py-3 px-2 text-xs font-bold uppercase border transition-all duration-200 flex flex-col items-center justify-center gap-1 ${
                          calcPlan === p.id 
                            ? 'bg-[#4fb7b3] text-black border-[#4fb7b3]' 
                            : 'bg-transparent text-white border-white/10 hover:border-white/30'
                        }`}
                      >
                        <span className="font-heading tracking-tight">{p.label}</span>
                        <span className="text-[9px] font-mono block opacity-80">{p.price}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Step 2: Add-on Checkboxes */}
                <div>
                  <span className="text-xs font-mono text-[#a8fbd3] uppercase tracking-wider block mb-4">2. Recursos e Opcionais Extra:</span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { id: 'copy', label: 'Copywriting Profissional', price: '+ R$ 100', desc: 'Textos focados em conversão.' },
                      { id: 'blog', label: 'Módulo de Blog Integrado', price: '+ R$ 150', desc: 'Estruturação de artigos SEO.' },
                      { id: 'whatsapp', label: 'Automação de WhatsApp', price: '+ R$ 50', desc: 'Botões e formulários diretos.' },
                      { id: 'maintenance', label: 'Suporte & Manutenção (Mensal)', price: '+ R$ 100', desc: 'Ajustes e atualizações de segurança.' }
                    ].map((addon) => (
                      <div 
                        key={addon.id}
                        onClick={() => toggleAddon(addon.id)}
                        className={`p-4 border transition-all duration-200 flex items-start gap-3 cursor-pointer hover:bg-white/5 ${
                          calcAddons[addon.id] ? 'border-[#4fb7b3]/60 bg-[#4fb7b3]/5' : 'border-white/10 bg-transparent'
                        }`}
                      >
                        <div className="mt-0.5">
                          <input 
                            type="checkbox" 
                            checked={calcAddons[addon.id]} 
                            readOnly 
                            className="accent-[#4fb7b3] w-4 h-4 rounded cursor-pointer"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-center gap-2">
                            <h5 className="text-xs font-bold text-white font-heading">{addon.label}</h5>
                            <span className="text-xs font-mono font-bold text-[#a8fbd3] shrink-0">{addon.price}</span>
                          </div>
                          <p className="text-[10px] text-gray-400 mt-0.5 font-light leading-relaxed">{addon.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Live Budget Counter */}
                <div className="pt-6 border-t border-white/10 flex justify-between items-baseline flex-wrap gap-4">
                  <span className="text-sm font-mono text-gray-400 uppercase">Investimento Estimado do Site:</span>
                  <div className="text-right">
                    <span className="text-3xl md:text-5xl font-bold tracking-tight text-[#a8fbd3]">
                      R$ {calculateTotal().toLocaleString('pt-BR')}
                    </span>
                    <span className="text-xs text-gray-400 block mt-1">Negociável direto no Zap</span>
                  </div>
                </div>

                {/* Briefing Fields */}
                <div className="border-t border-white/10 pt-6 space-y-4">
                  <span className="text-xs font-mono text-[#a8fbd3] uppercase tracking-wider block">3. Seus Dados de Contato:</span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-gray-400 block mb-1 uppercase">Seu Nome</label>
                      <input 
                        type="text" 
                        value={briefing.nome}
                        onChange={(e) => setBriefing(prev => ({ ...prev, nome: e.target.value }))}
                        placeholder="Ex: João"
                        className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white text-sm focus:outline-none focus:border-[#4fb7b3] transition-colors"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-gray-400 block mb-1 uppercase">Nome da sua Empresa</label>
                      <input 
                        type="text" 
                        value={briefing.empresa}
                        onChange={(e) => setBriefing(prev => ({ ...prev, empresa: e.target.value }))}
                        placeholder="Ex: Clínica Vitalis"
                        className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white text-sm focus:outline-none focus:border-[#4fb7b3] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-gray-400 block mb-1 uppercase">Seu E-mail</label>
                      <input 
                        type="email" 
                        value={briefing.email}
                        onChange={(e) => setBriefing(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="Ex: joao@gmail.com"
                        className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white text-sm focus:outline-none focus:border-[#4fb7b3] transition-colors"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-gray-400 block mb-1 uppercase">Seu WhatsApp</label>
                      <input 
                        type="tel" 
                        value={briefing.whatsapp}
                        onChange={(e) => setBriefing(prev => ({ ...prev, whatsapp: e.target.value }))}
                        placeholder="Ex: (11) 99999-9999"
                        className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white text-sm focus:outline-none focus:border-[#4fb7b3] transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-gray-400 block mb-1 uppercase">Mensagem Adicional / Sua Ideia</label>
                    <textarea 
                      rows={3}
                      value={briefing.mensagem}
                      onChange={(e) => setBriefing(prev => ({ ...prev, mensagem: e.target.value }))}
                      placeholder="Ex: Quero um site elegante e rápido para faturar mais com meus serviços."
                      className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white text-sm focus:outline-none focus:border-[#4fb7b3] transition-colors resize-none"
                    />
                  </div>
                </div>

                {/* CTA Submit to WhatsApp */}
                <button 
                  type="submit" 
                  className="w-full py-4.5 bg-[#25D366] text-white hover:bg-[#20ba5a] transition-all duration-300 font-bold uppercase tracking-wider flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(37,211,102,0.3)] border border-white/10 cursor-pointer"
                >
                  <PhoneCall className="w-4.5 h-4.5 fill-current" />
                  <span>Enviar Briefing & Chamar no WhatsApp</span>
                </button>

              </form>
            </div>

          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-white/10 py-16 bg-black/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
          <div>
             <div className="font-heading text-3xl md:text-4xl font-bold tracking-tighter mb-4 text-white">PINELLO.DEV</div>
             <p className="text-xs font-mono text-gray-400 leading-relaxed max-w-sm">
               © 2026 pinello.dev. Todos os direitos reservados. Atendimento e orçamentos via WhatsApp: <strong>11 943022963</strong>.
             </p>
          </div>
          
          <div className="flex gap-8 flex-wrap">
            <a href="https://x.com/GoogleAIStudio" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white font-bold uppercase text-xs tracking-widest transition-colors cursor-pointer" data-hover="true">
              Twitter
            </a>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white font-bold uppercase text-xs tracking-widest transition-colors cursor-pointer" data-hover="true">
              Github
            </a>
          </div>
        </div>
      </footer>

      {/* Service Detail Modal */}
      <AnimatePresence>
        {selectedService && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedService(null)}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md cursor-auto"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-5xl bg-[#090a10] border border-white/10 overflow-hidden flex flex-col md:flex-row shadow-2xl shadow-[#4fb7b3]/10"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedService(null)}
                className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/50 text-white hover:bg-white hover:text-black transition-colors"
                data-hover="true"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Navigation Buttons */}
              <button
                onClick={(e) => { e.stopPropagation(); navigateService('prev'); }}
                className="absolute left-4 bottom-4 translate-y-0 md:top-1/2 md:bottom-auto md:-translate-y-1/2 z-20 p-3 rounded-full bg-black/50 text-white hover:bg-white hover:text-black transition-colors border border-white/10 backdrop-blur-sm"
                data-hover="true"
                aria-label="Anterior"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <button
                onClick={(e) => { e.stopPropagation(); navigateService('next'); }}
                className="absolute right-4 bottom-4 translate-y-0 md:top-1/2 md:bottom-auto md:-translate-y-1/2 z-20 p-3 rounded-full bg-black/50 text-white hover:bg-white hover:text-black transition-colors border border-white/10 backdrop-blur-sm"
                data-hover="true"
                aria-label="Próximo"
              >
                <ChevronRight className="w-5 h-5" />
              </button>

              {/* Image Side */}
              <div className="w-full md:w-1/2 h-64 md:h-auto relative overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.img 
                    key={selectedService.id}
                    src={selectedService.image} 
                    alt={selectedService.name} 
                    initial={{ opacity: 0, scale: 1.1 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.4 }}
                    className="absolute inset-0 w-full h-full object-cover grayscale opacity-60"
                  />
                </AnimatePresence>
                <div className="absolute inset-0 bg-gradient-to-t from-[#090a10] via-transparent to-transparent md:bg-gradient-to-r md:from-[#090a10]/90 md:via-[#090a10]/40 md:to-transparent" />
              </div>

              {/* Content Side */}
              <div className="w-full md:w-1/2 p-8 pb-24 md:p-12 flex flex-col justify-center relative">
                <motion.div
                  key={selectedService.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 }}
                >
                  <div className="flex items-center gap-3 text-[#4fb7b3] mb-4">
                     <Clock className="w-4 h-4 animate-pulse" />
                     <span className="font-mono text-xs tracking-widest uppercase">Entrega em: {selectedService.deliveryTime}</span>
                  </div>
                  
                  <h3 className="text-3xl md:text-5xl font-heading font-bold uppercase leading-none mb-2 text-white">
                    {selectedService.name}
                  </h3>
                  
                  <p className="text-sm text-[#a8fbd3] font-mono tracking-widest uppercase mb-6">
                    {selectedService.category}
                  </p>
                  
                  <div className="h-px w-20 bg-white/20 mb-6" />
                  
                  <p className="text-gray-300 leading-relaxed text-base font-light mb-8">
                    {selectedService.description}
                  </p>

                  <h4 className="text-xs font-mono uppercase tracking-widest text-white/50 mb-3">Recursos Incluídos:</h4>
                  <ul className="space-y-2 mb-8">
                    {selectedService.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-sm text-gray-200">
                        <CheckCircle2 className="w-4 h-4 text-[#4fb7b3] mt-0.5 shrink-0" />
                        <span className="font-light">{feat}</span>
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => {
                      setSelectedService(null);
                      if (selectedService.id === '1') setCalcPlan('lp');
                      if (selectedService.id === '2') setCalcPlan('inst');
                      if (selectedService.id === '3') setCalcPlan('ecommerce');
                      scrollToSection('orcamento');
                    }}
                    className="px-6 py-3 border border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white transition-colors font-bold text-xs uppercase tracking-widest bg-transparent cursor-pointer flex items-center justify-center gap-2"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    Fazer Orçamento no Zap
                  </button>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
