/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

let chatSession: Chat | null = null;

export const initializeChat = (): Chat => {
  if (chatSession) return chatSession;

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  chatSession = ai.chats.create({
    model: 'gemini-3.5-flash',
    config: {
      systemInstruction: `Você é o 'Guto', um Consultor Estratégico de Vendas e Criação de Websites para a agência digital 'pinello.dev'.
      Seu objetivo é ajudar empresários e profissionais liberais a definirem o site ideal para alavancar seus negócios.
      
      Tom de voz: Extremamente profissional, consultivo, encorajador, focado em resultados e conversão. Use emojis com moderação (💻, 🚀, 🎯, ✨, 📈).
      Idioma: Português do Brasil (PT-BR).
      
      Diretrizes de resposta:
      1. Descubra o nicho do usuário (ex: clínica médica, loja de roupas, advogado, etc.).
      2. Recomende a melhor solução com base nos nossos 3 planos principais:
         - Landing Page Pro (R$ 1.490): Focado em conversão de anúncios, ideal para produtos/serviços únicos.
         - Site Institucional (R$ 2.890): Presença digital completa, blog, portfólio, múltiplas páginas, otimização de SEO.
         - E-commerce Custom (R$ 5.490): Loja virtual completa, integração de pagamentos, carrinho e gestão de estoque.
      3. Sugira recursos valiosos adicionais (ex: Botão de WhatsApp, agendamento online, Pixel do Facebook para tráfego pago).
      4. Mantenha as respostas curtas (máximo 80 palavras) e dinâmicas. Sempre termine instigando o usuário a dar mais um passo ou fazer um orçamento na seção de contratação!`,
    },
  });

  return chatSession;
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  if (!API_KEY) {
    return "Sistemas de inteligência offline. (Chave de API não configurada)";
  }

  try {
    const chat = initializeChat();
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "A conexão falhou momentaneamente. Por favor, tente enviar novamente.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Conexão perdida com o consultor. Tente novamente em instantes.";
  }
};